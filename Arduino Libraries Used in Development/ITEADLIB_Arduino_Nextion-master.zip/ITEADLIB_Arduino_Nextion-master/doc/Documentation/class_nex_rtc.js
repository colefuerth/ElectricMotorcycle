var class_nex_rtc =
[
    [ "read_rtc_time", "class_nex_rtc.html#a17230cd9342a905778fa4ee2e8609f02", null ],
    [ "read_rtc_time", "class_nex_rtc.html#aa1afa1d516db55dfbbf650cbe5180eab", null ],
    [ "read_rtc_time", "class_nex_rtc.html#ac71de2cd6f7598f05a5115642714d490", null ],
    [ "write_rtc_time", "class_nex_rtc.html#a9c55a15fa0a2b1511162facdc47f78b2", null ],
    [ "write_rtc_time", "class_nex_rtc.html#ab11da59341b52b0f686cb85a058d0962", null ]
];