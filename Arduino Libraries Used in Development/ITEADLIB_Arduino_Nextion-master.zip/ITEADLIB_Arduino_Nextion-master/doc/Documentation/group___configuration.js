var group___configuration =
[
    [ "dbSerial", "group___configuration.html#ga9abc2a70f2ba1b5a4edc63e807ee172e", null ],
    [ "DEBUG_SERIAL_ENABLE", "group___configuration.html#ga9b3a5e4cc28fc65f02c9b197e8a4c955", null ],
    [ "nexSerial", "group___configuration.html#ga2738b05a77cd5052e440af5b00b0ecbd", null ]
];