var class_nex_waveform =
[
    [ "NexWaveform", "class_nex_waveform.html#a4f18ca5050823e874d526141c8595514", null ],
    [ "addValue", "class_nex_waveform.html#a5b04ea7397b784947b845e2a03fc77e4", null ],
    [ "Get_background_color_bco", "class_nex_waveform.html#a66cec3c4d0d1a769dbf50c8092cc01d1", null ],
    [ "Get_channel_0_color_pco0", "class_nex_waveform.html#a09e36144f65c73b21edcfd5caff8a914", null ],
    [ "Get_grid_color_gdc", "class_nex_waveform.html#ac5a6622e9004600f24b12e60ebb6b984", null ],
    [ "Get_grid_height_gdh", "class_nex_waveform.html#a87f6baf5a7a9c52f54281865e757d9a3", null ],
    [ "Get_grid_width_gdw", "class_nex_waveform.html#ad5c4968c81d4941a08841cbaf217c631", null ],
    [ "Set_background_color_bco", "class_nex_waveform.html#aefec5eb25ee698c8c940c9190d60b696", null ],
    [ "Set_channel_0_color_pco0", "class_nex_waveform.html#ade323e0eae3b5058a76245e5ac97b037", null ],
    [ "Set_grid_color_gdc", "class_nex_waveform.html#ab396211f736824a0210446e68dc3edf4", null ],
    [ "Set_grid_height_gdh", "class_nex_waveform.html#a85e776a5347c22efd9abe9bb8cfdbddb", null ],
    [ "Set_grid_width_gdw", "class_nex_waveform.html#a41cb6d8b1ff6c309d1c4e8a1f73304fe", null ]
];